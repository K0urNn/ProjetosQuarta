﻿namespace Jogo_da_memoria {
    partial class Form1 {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing) {
            if (disposing && (components != null)) {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent() {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.pictureBox39 = new System.Windows.Forms.PictureBox();
            this.pictureBox40 = new System.Windows.Forms.PictureBox();
            this.pictureBox41 = new System.Windows.Forms.PictureBox();
            this.pictureBox42 = new System.Windows.Forms.PictureBox();
            this.pictureBox43 = new System.Windows.Forms.PictureBox();
            this.pictureBox44 = new System.Windows.Forms.PictureBox();
            this.pictureBox45 = new System.Windows.Forms.PictureBox();
            this.pictureBox46 = new System.Windows.Forms.PictureBox();
            this.pictureBox47 = new System.Windows.Forms.PictureBox();
            this.pictureBox48 = new System.Windows.Forms.PictureBox();
            this.pictureBox49 = new System.Windows.Forms.PictureBox();
            this.pictureBox50 = new System.Windows.Forms.PictureBox();
            this.pictureBox51 = new System.Windows.Forms.PictureBox();
            this.pictureBox52 = new System.Windows.Forms.PictureBox();
            this.pictureBox53 = new System.Windows.Forms.PictureBox();
            this.pictureBox54 = new System.Windows.Forms.PictureBox();
            this.pictureBox55 = new System.Windows.Forms.PictureBox();
            this.pictureBox56 = new System.Windows.Forms.PictureBox();
            this.lblMovimento = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox39)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox40)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox41)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox42)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox43)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox44)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox45)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox46)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox47)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox48)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox49)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox50)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox51)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox52)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox53)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox54)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox55)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox56)).BeginInit();
            this.SuspendLayout();
            // 
            // pictureBox39
            // 
            this.pictureBox39.Image = global::Jogo_da_memoria.Properties.Resources.Pixelart___Eye;
            this.pictureBox39.Location = new System.Drawing.Point(110, 26);
            this.pictureBox39.Name = "pictureBox39";
            this.pictureBox39.Size = new System.Drawing.Size(124, 113);
            this.pictureBox39.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox39.TabIndex = 0;
            this.pictureBox39.TabStop = false;
            this.pictureBox39.Tag = "0";
            this.pictureBox39.Click += new System.EventHandler(this.ImagensClick_Click);
            // 
            // pictureBox40
            // 
            this.pictureBox40.Image = global::Jogo_da_memoria.Properties.Resources.Pixelart___Eye;
            this.pictureBox40.Location = new System.Drawing.Point(240, 26);
            this.pictureBox40.Name = "pictureBox40";
            this.pictureBox40.Size = new System.Drawing.Size(124, 113);
            this.pictureBox40.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox40.TabIndex = 1;
            this.pictureBox40.TabStop = false;
            this.pictureBox40.Tag = "0";
            this.pictureBox40.Click += new System.EventHandler(this.ImagensClick_Click);
            // 
            // pictureBox41
            // 
            this.pictureBox41.Image = global::Jogo_da_memoria.Properties.Resources.Pixelart___Ghost;
            this.pictureBox41.Location = new System.Drawing.Point(370, 26);
            this.pictureBox41.Name = "pictureBox41";
            this.pictureBox41.Size = new System.Drawing.Size(124, 113);
            this.pictureBox41.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox41.TabIndex = 2;
            this.pictureBox41.TabStop = false;
            this.pictureBox41.Tag = "1";
            this.pictureBox41.Click += new System.EventHandler(this.ImagensClick_Click);
            // 
            // pictureBox42
            // 
            this.pictureBox42.Image = global::Jogo_da_memoria.Properties.Resources.Pixelart___Ghost;
            this.pictureBox42.Location = new System.Drawing.Point(500, 26);
            this.pictureBox42.Name = "pictureBox42";
            this.pictureBox42.Size = new System.Drawing.Size(124, 113);
            this.pictureBox42.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox42.TabIndex = 3;
            this.pictureBox42.TabStop = false;
            this.pictureBox42.Tag = "1";
            this.pictureBox42.Click += new System.EventHandler(this.ImagensClick_Click);
            // 
            // pictureBox43
            // 
            this.pictureBox43.Image = global::Jogo_da_memoria.Properties.Resources.Pixelart___Grimm;
            this.pictureBox43.Location = new System.Drawing.Point(630, 26);
            this.pictureBox43.Name = "pictureBox43";
            this.pictureBox43.Size = new System.Drawing.Size(124, 113);
            this.pictureBox43.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox43.TabIndex = 4;
            this.pictureBox43.TabStop = false;
            this.pictureBox43.Tag = "2";
            this.pictureBox43.Click += new System.EventHandler(this.ImagensClick_Click);
            // 
            // pictureBox44
            // 
            this.pictureBox44.Image = global::Jogo_da_memoria.Properties.Resources.Pixelart___Grimm;
            this.pictureBox44.Location = new System.Drawing.Point(760, 26);
            this.pictureBox44.Name = "pictureBox44";
            this.pictureBox44.Size = new System.Drawing.Size(124, 113);
            this.pictureBox44.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox44.TabIndex = 5;
            this.pictureBox44.TabStop = false;
            this.pictureBox44.Tag = "2";
            this.pictureBox44.Click += new System.EventHandler(this.ImagensClick_Click);
            // 
            // pictureBox45
            // 
            this.pictureBox45.Image = global::Jogo_da_memoria.Properties.Resources.Pixelart___Hollow;
            this.pictureBox45.Location = new System.Drawing.Point(110, 145);
            this.pictureBox45.Name = "pictureBox45";
            this.pictureBox45.Size = new System.Drawing.Size(124, 113);
            this.pictureBox45.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox45.TabIndex = 6;
            this.pictureBox45.TabStop = false;
            this.pictureBox45.Tag = "3";
            this.pictureBox45.Click += new System.EventHandler(this.ImagensClick_Click);
            // 
            // pictureBox46
            // 
            this.pictureBox46.Image = global::Jogo_da_memoria.Properties.Resources.Pixelart___Hollow;
            this.pictureBox46.Location = new System.Drawing.Point(240, 145);
            this.pictureBox46.Name = "pictureBox46";
            this.pictureBox46.Size = new System.Drawing.Size(124, 113);
            this.pictureBox46.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox46.TabIndex = 7;
            this.pictureBox46.TabStop = false;
            this.pictureBox46.Tag = "3";
            this.pictureBox46.Click += new System.EventHandler(this.ImagensClick_Click);
            // 
            // pictureBox47
            // 
            this.pictureBox47.Image = global::Jogo_da_memoria.Properties.Resources.pixelart___Potion;
            this.pictureBox47.Location = new System.Drawing.Point(370, 145);
            this.pictureBox47.Name = "pictureBox47";
            this.pictureBox47.Size = new System.Drawing.Size(124, 113);
            this.pictureBox47.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox47.TabIndex = 8;
            this.pictureBox47.TabStop = false;
            this.pictureBox47.Tag = "4";
            this.pictureBox47.Click += new System.EventHandler(this.ImagensClick_Click);
            // 
            // pictureBox48
            // 
            this.pictureBox48.Image = global::Jogo_da_memoria.Properties.Resources.pixelart___Potion;
            this.pictureBox48.Location = new System.Drawing.Point(500, 145);
            this.pictureBox48.Name = "pictureBox48";
            this.pictureBox48.Size = new System.Drawing.Size(124, 113);
            this.pictureBox48.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox48.TabIndex = 9;
            this.pictureBox48.TabStop = false;
            this.pictureBox48.Tag = "4";
            this.pictureBox48.Click += new System.EventHandler(this.ImagensClick_Click);
            // 
            // pictureBox49
            // 
            this.pictureBox49.Image = global::Jogo_da_memoria.Properties.Resources.Pixelart___Pumpkin;
            this.pictureBox49.Location = new System.Drawing.Point(630, 145);
            this.pictureBox49.Name = "pictureBox49";
            this.pictureBox49.Size = new System.Drawing.Size(124, 113);
            this.pictureBox49.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox49.TabIndex = 10;
            this.pictureBox49.TabStop = false;
            this.pictureBox49.Tag = "5";
            this.pictureBox49.Click += new System.EventHandler(this.ImagensClick_Click);
            // 
            // pictureBox50
            // 
            this.pictureBox50.Image = global::Jogo_da_memoria.Properties.Resources.Pixelart___Pumpkin;
            this.pictureBox50.Location = new System.Drawing.Point(760, 145);
            this.pictureBox50.Name = "pictureBox50";
            this.pictureBox50.Size = new System.Drawing.Size(124, 113);
            this.pictureBox50.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox50.TabIndex = 11;
            this.pictureBox50.TabStop = false;
            this.pictureBox50.Tag = "5";
            this.pictureBox50.Click += new System.EventHandler(this.ImagensClick_Click);
            // 
            // pictureBox51
            // 
            this.pictureBox51.Image = global::Jogo_da_memoria.Properties.Resources.Pixelart___Reaper;
            this.pictureBox51.Location = new System.Drawing.Point(110, 264);
            this.pictureBox51.Name = "pictureBox51";
            this.pictureBox51.Size = new System.Drawing.Size(124, 113);
            this.pictureBox51.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox51.TabIndex = 12;
            this.pictureBox51.TabStop = false;
            this.pictureBox51.Tag = "6";
            this.pictureBox51.Click += new System.EventHandler(this.ImagensClick_Click);
            // 
            // pictureBox52
            // 
            this.pictureBox52.Image = global::Jogo_da_memoria.Properties.Resources.Pixelart___Skull;
            this.pictureBox52.Location = new System.Drawing.Point(370, 264);
            this.pictureBox52.Name = "pictureBox52";
            this.pictureBox52.Size = new System.Drawing.Size(124, 113);
            this.pictureBox52.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox52.TabIndex = 13;
            this.pictureBox52.TabStop = false;
            this.pictureBox52.Tag = "7";
            this.pictureBox52.Click += new System.EventHandler(this.ImagensClick_Click);
            // 
            // pictureBox53
            // 
            this.pictureBox53.Image = global::Jogo_da_memoria.Properties.Resources.Pixelart___Reaper;
            this.pictureBox53.Location = new System.Drawing.Point(240, 264);
            this.pictureBox53.Name = "pictureBox53";
            this.pictureBox53.Size = new System.Drawing.Size(124, 113);
            this.pictureBox53.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox53.TabIndex = 13;
            this.pictureBox53.TabStop = false;
            this.pictureBox53.Tag = "6";
            this.pictureBox53.Click += new System.EventHandler(this.ImagensClick_Click);
            // 
            // pictureBox54
            // 
            this.pictureBox54.Image = global::Jogo_da_memoria.Properties.Resources.Pixelart___Skull;
            this.pictureBox54.Location = new System.Drawing.Point(500, 264);
            this.pictureBox54.Name = "pictureBox54";
            this.pictureBox54.Size = new System.Drawing.Size(124, 113);
            this.pictureBox54.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox54.TabIndex = 14;
            this.pictureBox54.TabStop = false;
            this.pictureBox54.Tag = "7";
            this.pictureBox54.Click += new System.EventHandler(this.ImagensClick_Click);
            // 
            // pictureBox55
            // 
            this.pictureBox55.Image = global::Jogo_da_memoria.Properties.Resources.Pixelart___Spider;
            this.pictureBox55.Location = new System.Drawing.Point(630, 264);
            this.pictureBox55.Name = "pictureBox55";
            this.pictureBox55.Size = new System.Drawing.Size(124, 113);
            this.pictureBox55.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox55.TabIndex = 15;
            this.pictureBox55.TabStop = false;
            this.pictureBox55.Tag = "8";
            this.pictureBox55.Click += new System.EventHandler(this.ImagensClick_Click);
            // 
            // pictureBox56
            // 
            this.pictureBox56.Image = global::Jogo_da_memoria.Properties.Resources.Pixelart___Spider;
            this.pictureBox56.Location = new System.Drawing.Point(760, 264);
            this.pictureBox56.Name = "pictureBox56";
            this.pictureBox56.Size = new System.Drawing.Size(124, 113);
            this.pictureBox56.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox56.TabIndex = 16;
            this.pictureBox56.TabStop = false;
            this.pictureBox56.Tag = "8";
            this.pictureBox56.Click += new System.EventHandler(this.ImagensClick_Click);
            // 
            // lblMovimento
            // 
            this.lblMovimento.AutoSize = true;
            this.lblMovimento.BackColor = System.Drawing.Color.Transparent;
            this.lblMovimento.Font = new System.Drawing.Font("Times New Roman", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMovimento.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.lblMovimento.Location = new System.Drawing.Point(228, 410);
            this.lblMovimento.Name = "lblMovimento";
            this.lblMovimento.Size = new System.Drawing.Size(362, 68);
            this.lblMovimento.TabIndex = 17;
            this.lblMovimento.Text = "Movimentos:";
            // 
            // Form1
            // 
            this.BackgroundImage = global::Jogo_da_memoria.Properties.Resources.BackGorund;
            this.ClientSize = new System.Drawing.Size(987, 511);
            this.Controls.Add(this.lblMovimento);
            this.Controls.Add(this.pictureBox56);
            this.Controls.Add(this.pictureBox55);
            this.Controls.Add(this.pictureBox54);
            this.Controls.Add(this.pictureBox53);
            this.Controls.Add(this.pictureBox52);
            this.Controls.Add(this.pictureBox51);
            this.Controls.Add(this.pictureBox50);
            this.Controls.Add(this.pictureBox49);
            this.Controls.Add(this.pictureBox48);
            this.Controls.Add(this.pictureBox47);
            this.Controls.Add(this.pictureBox46);
            this.Controls.Add(this.pictureBox45);
            this.Controls.Add(this.pictureBox44);
            this.Controls.Add(this.pictureBox43);
            this.Controls.Add(this.pictureBox42);
            this.Controls.Add(this.pictureBox41);
            this.Controls.Add(this.pictureBox40);
            this.Controls.Add(this.pictureBox39);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "Form1";
            this.Text = "JogoMemoria";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox39)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox40)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox41)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox42)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox43)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox44)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox45)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox46)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox47)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox48)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox49)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox50)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox51)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox52)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox53)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox54)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox55)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox56)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.PictureBox pictureBox5;
        private System.Windows.Forms.PictureBox pictureBox6;
        private System.Windows.Forms.PictureBox pictureBox7;
        private System.Windows.Forms.PictureBox pictureBox8;
        private System.Windows.Forms.PictureBox pictureBox9;
        private System.Windows.Forms.PictureBox pictureBox10;
        private System.Windows.Forms.PictureBox pictureBox11;
        private System.Windows.Forms.PictureBox pictureBox12;
        private System.Windows.Forms.PictureBox pictureBox13;
        private System.Windows.Forms.PictureBox pictureBox14;
        private System.Windows.Forms.PictureBox pictureBox15;
        private System.Windows.Forms.PictureBox pictureBox16;
        private System.Windows.Forms.PictureBox pictureBox17;
        private System.Windows.Forms.PictureBox pictureBox18;
        private System.Windows.Forms.Label lblmovimentos;
        private System.Windows.Forms.PictureBox pictureBox19;
        private System.Windows.Forms.PictureBox pictureBox20;
        private System.Windows.Forms.PictureBox pictureBox21;
        private System.Windows.Forms.PictureBox pictureBox22;
        private System.Windows.Forms.PictureBox pictureBox23;
        private System.Windows.Forms.PictureBox pictureBox24;
        private System.Windows.Forms.PictureBox pictureBox25;
        private System.Windows.Forms.PictureBox pictureBox26;
        private System.Windows.Forms.PictureBox pictureBox27;
        private System.Windows.Forms.PictureBox pictureBox28;
        private System.Windows.Forms.PictureBox pictureBox29;
        private System.Windows.Forms.PictureBox pictureBox30;
        private System.Windows.Forms.PictureBox pictureBox31;
        private System.Windows.Forms.PictureBox pictureBox32;
        private System.Windows.Forms.PictureBox pictureBox33;
        private System.Windows.Forms.PictureBox pictureBox34;
        private System.Windows.Forms.PictureBox pictureBox35;
        private System.Windows.Forms.PictureBox pictureBox36;
        private System.Windows.Forms.PictureBox pictureBox37;
        private System.Windows.Forms.PictureBox pictureBox38;
        private System.Windows.Forms.PictureBox pictureBox39;
        private System.Windows.Forms.PictureBox pictureBox40;
        private System.Windows.Forms.PictureBox pictureBox41;
        private System.Windows.Forms.PictureBox pictureBox42;
        private System.Windows.Forms.PictureBox pictureBox43;
        private System.Windows.Forms.PictureBox pictureBox44;
        private System.Windows.Forms.PictureBox pictureBox45;
        private System.Windows.Forms.PictureBox pictureBox46;
        private System.Windows.Forms.PictureBox pictureBox47;
        private System.Windows.Forms.PictureBox pictureBox48;
        private System.Windows.Forms.PictureBox pictureBox49;
        private System.Windows.Forms.PictureBox pictureBox50;
        private System.Windows.Forms.PictureBox pictureBox51;
        private System.Windows.Forms.PictureBox pictureBox52;
        private System.Windows.Forms.PictureBox pictureBox53;
        private System.Windows.Forms.PictureBox pictureBox54;
        private System.Windows.Forms.PictureBox pictureBox55;
        private System.Windows.Forms.PictureBox pictureBox56;
        private System.Windows.Forms.Label lblMovimento;
    }
}

