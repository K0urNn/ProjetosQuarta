﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Media;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace URNA3
{
    public partial class frmUrna : Form
    {
        private Dictionary<string, Candidato> _dicCanditado;
        private Dictionary<int, int> _votos;

        public frmUrna()
        {
            InitializeComponent();
            _dicCanditado = new Dictionary<string, Candidato>();
            _votos = new Dictionary<int, int>();

            _dicCanditado.Add("51", new Candidato() { Id = 51, Nome = "Junin", Partido = "Esquerda", Foto = Properties.Resources.Junin2 });
            _dicCanditado.Add("52", new Candidato() { Id = 52, Nome = "Pedrin", Partido = "Direita", Foto = Properties.Resources.Pedrin2 });
            _dicCanditado.Add("53", new Candidato() { Id = 53, Nome = "Branco" });

            _votos.Add(51, 0);
            _votos.Add(52, 0);
            _votos.Add(53, 0);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            RegistrarDigito("1");
        }

        private void bt2_Click(object sender, EventArgs e)
        {
            RegistrarDigito("2");
        }

        private void bt3_Click(object sender, EventArgs e)
        {
            RegistrarDigito("3");
        }

        private void bt4_Click(object sender, EventArgs e)
        {
            RegistrarDigito("4");
        }

        private void bt5_Click(object sender, EventArgs e)
        {
            RegistrarDigito("5");
        }

        private void bt6_Click(object sender, EventArgs e)
        {
            RegistrarDigito("6");
        }

        private void bt7_Click(object sender, EventArgs e)
        {
            RegistrarDigito("7");
        }

        private void bt8_Click(object sender, EventArgs e)
        {
            RegistrarDigito("8");
        }

        private void bt9_Click(object sender, EventArgs e)
        {
            RegistrarDigito("9");
        }

        private void bt0_Click(object sender, EventArgs e)
        {
            RegistrarDigito("0");
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            pnFim.Visible = true;
            Limpar();

            
            if (string.IsNullOrEmpty(lbNome.Text) && string.IsNullOrEmpty(lbPartido.Text))
            {
                
                _votos[53]++;
                //MessageBox.Show("Voto em branco registrado.");
            }
            else
            {
                
                string candidatoKey = txtN1.Text + txtN2.Text;

                if (_dicCanditado.ContainsKey(candidatoKey))
                {
                    
                    int candidatoId = _dicCanditado[candidatoKey].Id;

                    
                    _votos[candidatoId]++;
                    //MessageBox.Show($"Voto registrado para {lbNome.Text} ({lbPartido.Text}).");
                }
                else
                {
                    MessageBox.Show("Candidato Não encontrado");
                }
            }

             
            using (MemoryStream ms = new MemoryStream(Properties.Resources.urna))
            {
                SoundPlayer player = new SoundPlayer(ms);
                player.Play();
            }

            
            relogio.Tick += new EventHandler(AcaoFinal);
            relogio.Interval = 3000;
            relogio.Enabled = true;
            relogio.Start();
        }


        private void button2_Click(object sender, EventArgs e)
        {
            Limpar();
            relogio.Stop();
            relogio.Enabled = false;

        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txtN1.Text))
            {
                MessageBox.Show("Favor informar o candidato.");
                    return;
            }
            int candidatoId = int.Parse(txtN1.Text + txtN2.Text);

            if (_votos.ContainsKey(candidatoId))
            {
                _votos[candidatoId]++;
                //MessageBox.Show($"Voto registrado para {lbNome.Text} ({lbPartido.Text}).");
            }
            else
            {
                MessageBox.Show("Candidato Não encontrado");
            }

            pnFim.Visible = true;
            Limpar();

            using (MemoryStream ms = new MemoryStream(Properties.Resources.urna))
            {
                SoundPlayer player = new SoundPlayer(ms);
                player.Play();
            }

            relogio.Tick += new EventHandler(AcaoFinal);
            relogio.Interval = 3000;
            relogio.Enabled = true;
            relogio.Start();

        }
        private void AcaoFinal(object myObject, EventArgs myEventArgs)
        {
            relogio.Stop();
            relogio.Enabled = false;
            pnFim.Visible = false;

        }
        

        private void tbPresidente_TextChanged(object sender, EventArgs e)
        {

        }

        private void tbNumero_TextChanged(object sender, EventArgs e)
        {

        }

        private void tbPartido_TextChanged(object sender, EventArgs e)
        {

        }

        private void URNA_Load(object sender, EventArgs e)
        {

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtN1_TextChanged(object sender, EventArgs e)
        {

        }

        private void lb2_Click(object sender, EventArgs e)
        {

        }

        private void lbNome_Click(object sender, EventArgs e)
        {

        }

        private void pbfoto_Click(object sender, EventArgs e)
        {

        }

        private void tbFim_TextChanged(object sender, EventArgs e)
        {

        }

        private void pn2_Paint(object sender, PaintEventArgs e)
        {

        }
        private void RegistrarDigito(string digito)
        {
            if (string.IsNullOrEmpty(txtN1.Text))
                txtN1.Text = digito;
            else
            {
                txtN2.Text = digito;
                PreencherCandidato(txtN1.Text, txtN2.Text);
            }
            
        }

        private void PreencherCandidato(string d1, string d2)
        {
            if (_dicCanditado.ContainsKey(d1 + d2))
            {
                lbNome.Text = _dicCanditado[d1 + d2].Nome;
                lbPartido.Text = _dicCanditado[d1 + d2].Partido;
                pbfoto.Image = _dicCanditado[d1 + d2].Foto;
            }
            else
            {
                MessageBox.Show("Candidato Não encontrado");
            }
        }
        private void DisplayVotos(string candidatoKey)
        {
            
            int candidatoId = int.Parse(candidatoKey);
            if (_votos.ContainsKey(candidatoId))
            {
                lbResultado.Text = $"Votos: {_votos[candidatoId]}";  
            }
        }

        private void Limpar()
        {
            txtN1.Text = "";
            txtN2.Text = "";
            lbNome.Text = string.Empty;
            lbPartido.Text = string.Empty;
            pbfoto.Image = null;
        }

        private void btnResultado_Click(object sender, EventArgs e)
        {
            {
                
                lbResultado.Text = $"Resultado:\n" +
                                    $"{_dicCanditado["51"].Nome} - {_votos[51]} votos\n" +
                                    $"{_dicCanditado["52"].Nome} - {_votos[52]} votos\n" +
                                    $"{_dicCanditado["53"].Nome} - {_votos[53]} votos";
            }
        }

        private void lbResultado_Click(object sender, EventArgs e)
        {

        }
    }
    public class Candidato
    {
        public int Id { get; set; }
        public string Nome { get; set; }

        public string Partido { get; set; }

        public Image Foto { get; set; }
    }
}
