﻿namespace URNA3
{
    partial class frmUrna
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmUrna));
            this.bt1 = new System.Windows.Forms.Button();
            this.bt2 = new System.Windows.Forms.Button();
            this.bt3 = new System.Windows.Forms.Button();
            this.bt4 = new System.Windows.Forms.Button();
            this.bt5 = new System.Windows.Forms.Button();
            this.bt6 = new System.Windows.Forms.Button();
            this.bt7 = new System.Windows.Forms.Button();
            this.bt8 = new System.Windows.Forms.Button();
            this.bt9 = new System.Windows.Forms.Button();
            this.bt0 = new System.Windows.Forms.Button();
            this.bt10 = new System.Windows.Forms.Button();
            this.bt11 = new System.Windows.Forms.Button();
            this.bt12 = new System.Windows.Forms.Button();
            this.pn1 = new System.Windows.Forms.Panel();
            this.pnFim = new System.Windows.Forms.Panel();
            this.tbFim = new System.Windows.Forms.TextBox();
            this.pbfoto = new System.Windows.Forms.PictureBox();
            this.lbPartido = new System.Windows.Forms.Label();
            this.lbNome = new System.Windows.Forms.Label();
            this.txtN2 = new System.Windows.Forms.TextBox();
            this.txtN1 = new System.Windows.Forms.TextBox();
            this.tbPartido = new System.Windows.Forms.TextBox();
            this.tbNumero = new System.Windows.Forms.TextBox();
            this.tbNome = new System.Windows.Forms.TextBox();
            this.tbPresidente = new System.Windows.Forms.TextBox();
            this.relogio = new System.Windows.Forms.Timer(this.components);
            this.lbVotos = new System.Windows.Forms.Label();
            this.lbResultado = new System.Windows.Forms.Label();
            this.btnResultado = new System.Windows.Forms.Button();
            this.pn1.SuspendLayout();
            this.pnFim.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbfoto)).BeginInit();
            this.SuspendLayout();
            // 
            // bt1
            // 
            this.bt1.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.bt1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.bt1.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.bt1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F);
            this.bt1.ForeColor = System.Drawing.Color.Snow;
            this.bt1.Location = new System.Drawing.Point(578, 313);
            this.bt1.Name = "bt1";
            this.bt1.Size = new System.Drawing.Size(28, 23);
            this.bt1.TabIndex = 0;
            this.bt1.Text = "1";
            this.bt1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.bt1.UseVisualStyleBackColor = false;
            this.bt1.Click += new System.EventHandler(this.button1_Click);
            // 
            // bt2
            // 
            this.bt2.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.bt2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.bt2.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.bt2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F);
            this.bt2.ForeColor = System.Drawing.Color.Snow;
            this.bt2.Location = new System.Drawing.Point(612, 313);
            this.bt2.Name = "bt2";
            this.bt2.Size = new System.Drawing.Size(28, 23);
            this.bt2.TabIndex = 1;
            this.bt2.Text = "2";
            this.bt2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.bt2.UseVisualStyleBackColor = false;
            this.bt2.Click += new System.EventHandler(this.bt2_Click);
            // 
            // bt3
            // 
            this.bt3.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.bt3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.bt3.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.bt3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F);
            this.bt3.ForeColor = System.Drawing.Color.Snow;
            this.bt3.Location = new System.Drawing.Point(646, 313);
            this.bt3.Name = "bt3";
            this.bt3.Size = new System.Drawing.Size(28, 23);
            this.bt3.TabIndex = 2;
            this.bt3.Text = "3";
            this.bt3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.bt3.UseVisualStyleBackColor = false;
            this.bt3.Click += new System.EventHandler(this.bt3_Click);
            // 
            // bt4
            // 
            this.bt4.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.bt4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.bt4.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.bt4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F);
            this.bt4.ForeColor = System.Drawing.Color.Snow;
            this.bt4.Location = new System.Drawing.Point(578, 342);
            this.bt4.Name = "bt4";
            this.bt4.Size = new System.Drawing.Size(28, 23);
            this.bt4.TabIndex = 3;
            this.bt4.Text = "4";
            this.bt4.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.bt4.UseVisualStyleBackColor = false;
            this.bt4.Click += new System.EventHandler(this.bt4_Click);
            // 
            // bt5
            // 
            this.bt5.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.bt5.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.bt5.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.bt5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F);
            this.bt5.ForeColor = System.Drawing.Color.Snow;
            this.bt5.Location = new System.Drawing.Point(612, 342);
            this.bt5.Name = "bt5";
            this.bt5.Size = new System.Drawing.Size(28, 23);
            this.bt5.TabIndex = 4;
            this.bt5.Text = "5";
            this.bt5.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.bt5.UseVisualStyleBackColor = false;
            this.bt5.Click += new System.EventHandler(this.bt5_Click);
            // 
            // bt6
            // 
            this.bt6.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.bt6.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.bt6.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.bt6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F);
            this.bt6.ForeColor = System.Drawing.Color.Snow;
            this.bt6.Location = new System.Drawing.Point(646, 342);
            this.bt6.Name = "bt6";
            this.bt6.Size = new System.Drawing.Size(28, 23);
            this.bt6.TabIndex = 5;
            this.bt6.Text = "6";
            this.bt6.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.bt6.UseVisualStyleBackColor = false;
            this.bt6.Click += new System.EventHandler(this.bt6_Click);
            // 
            // bt7
            // 
            this.bt7.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.bt7.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.bt7.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.bt7.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F);
            this.bt7.ForeColor = System.Drawing.Color.Snow;
            this.bt7.Location = new System.Drawing.Point(578, 371);
            this.bt7.Name = "bt7";
            this.bt7.Size = new System.Drawing.Size(28, 23);
            this.bt7.TabIndex = 6;
            this.bt7.Text = "7";
            this.bt7.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.bt7.UseVisualStyleBackColor = false;
            this.bt7.Click += new System.EventHandler(this.bt7_Click);
            // 
            // bt8
            // 
            this.bt8.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.bt8.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.bt8.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.bt8.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F);
            this.bt8.ForeColor = System.Drawing.Color.Snow;
            this.bt8.Location = new System.Drawing.Point(612, 371);
            this.bt8.Name = "bt8";
            this.bt8.Size = new System.Drawing.Size(28, 23);
            this.bt8.TabIndex = 7;
            this.bt8.Text = "8";
            this.bt8.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.bt8.UseVisualStyleBackColor = false;
            this.bt8.Click += new System.EventHandler(this.bt8_Click);
            // 
            // bt9
            // 
            this.bt9.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.bt9.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.bt9.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.bt9.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F);
            this.bt9.ForeColor = System.Drawing.Color.Snow;
            this.bt9.Location = new System.Drawing.Point(646, 371);
            this.bt9.Name = "bt9";
            this.bt9.Size = new System.Drawing.Size(28, 23);
            this.bt9.TabIndex = 8;
            this.bt9.Text = "9";
            this.bt9.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.bt9.UseVisualStyleBackColor = false;
            this.bt9.Click += new System.EventHandler(this.bt9_Click);
            // 
            // bt0
            // 
            this.bt0.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.bt0.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.bt0.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.bt0.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F);
            this.bt0.ForeColor = System.Drawing.Color.Snow;
            this.bt0.Location = new System.Drawing.Point(612, 400);
            this.bt0.Name = "bt0";
            this.bt0.Size = new System.Drawing.Size(28, 23);
            this.bt0.TabIndex = 9;
            this.bt0.Text = "0";
            this.bt0.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.bt0.UseVisualStyleBackColor = false;
            this.bt0.Click += new System.EventHandler(this.bt0_Click);
            // 
            // bt10
            // 
            this.bt10.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.bt10.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.bt10.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.bt10.Font = new System.Drawing.Font("Microsoft Sans Serif", 5F);
            this.bt10.ForeColor = System.Drawing.Color.Black;
            this.bt10.Location = new System.Drawing.Point(560, 425);
            this.bt10.Name = "bt10";
            this.bt10.Size = new System.Drawing.Size(46, 26);
            this.bt10.TabIndex = 10;
            this.bt10.Text = "BRANCO";
            this.bt10.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.bt10.UseVisualStyleBackColor = false;
            this.bt10.Click += new System.EventHandler(this.button1_Click_1);
            // 
            // bt11
            // 
            this.bt11.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.bt11.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.bt11.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.bt11.Font = new System.Drawing.Font("Microsoft Sans Serif", 3.2F);
            this.bt11.ForeColor = System.Drawing.Color.Black;
            this.bt11.Location = new System.Drawing.Point(612, 429);
            this.bt11.Name = "bt11";
            this.bt11.Size = new System.Drawing.Size(41, 22);
            this.bt11.TabIndex = 11;
            this.bt11.Text = "CORRIGIR";
            this.bt11.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.bt11.UseVisualStyleBackColor = false;
            this.bt11.Click += new System.EventHandler(this.button2_Click);
            // 
            // bt12
            // 
            this.bt12.BackColor = System.Drawing.Color.LimeGreen;
            this.bt12.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.bt12.CausesValidation = false;
            this.bt12.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.bt12.Font = new System.Drawing.Font("Microsoft Sans Serif", 3.5F);
            this.bt12.ForeColor = System.Drawing.Color.Black;
            this.bt12.Location = new System.Drawing.Point(659, 423);
            this.bt12.Name = "bt12";
            this.bt12.Size = new System.Drawing.Size(42, 26);
            this.bt12.TabIndex = 12;
            this.bt12.Text = "CONFIRMAR";
            this.bt12.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.bt12.UseVisualStyleBackColor = false;
            this.bt12.Click += new System.EventHandler(this.button3_Click);
            // 
            // pn1
            // 
            this.pn1.Controls.Add(this.pbfoto);
            this.pn1.Controls.Add(this.lbPartido);
            this.pn1.Controls.Add(this.lbNome);
            this.pn1.Controls.Add(this.txtN2);
            this.pn1.Controls.Add(this.txtN1);
            this.pn1.Controls.Add(this.tbPartido);
            this.pn1.Controls.Add(this.tbNumero);
            this.pn1.Controls.Add(this.tbNome);
            this.pn1.Controls.Add(this.tbPresidente);
            this.pn1.Location = new System.Drawing.Point(264, 285);
            this.pn1.Name = "pn1";
            this.pn1.Size = new System.Drawing.Size(274, 166);
            this.pn1.TabIndex = 13;
            this.pn1.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint);
            // 
            // pnFim
            // 
            this.pnFim.Controls.Add(this.tbFim);
            this.pnFim.Location = new System.Drawing.Point(264, 285);
            this.pnFim.Name = "pnFim";
            this.pnFim.Size = new System.Drawing.Size(274, 168);
            this.pnFim.TabIndex = 14;
            this.pnFim.Paint += new System.Windows.Forms.PaintEventHandler(this.pn2_Paint);
            // 
            // tbFim
            // 
            this.tbFim.AccessibleRole = System.Windows.Forms.AccessibleRole.None;
            this.tbFim.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.tbFim.Font = new System.Drawing.Font("Segoe UI", 20F);
            this.tbFim.Location = new System.Drawing.Point(91, 66);
            this.tbFim.Name = "tbFim";
            this.tbFim.Size = new System.Drawing.Size(100, 36);
            this.tbFim.TabIndex = 0;
            this.tbFim.Text = "FIM";
            this.tbFim.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.tbFim.TextChanged += new System.EventHandler(this.tbFim_TextChanged);
            // 
            // pbfoto
            // 
            this.pbfoto.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pbfoto.Location = new System.Drawing.Point(185, 17);
            this.pbfoto.Name = "pbfoto";
            this.pbfoto.Size = new System.Drawing.Size(73, 74);
            this.pbfoto.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbfoto.TabIndex = 8;
            this.pbfoto.TabStop = false;
            this.pbfoto.Click += new System.EventHandler(this.pbfoto_Click);
            // 
            // lbPartido
            // 
            this.lbPartido.AutoSize = true;
            this.lbPartido.Location = new System.Drawing.Point(43, 138);
            this.lbPartido.Name = "lbPartido";
            this.lbPartido.Size = new System.Drawing.Size(16, 13);
            this.lbPartido.TabIndex = 7;
            this.lbPartido.Text = "...";
            this.lbPartido.Click += new System.EventHandler(this.lb2_Click);
            // 
            // lbNome
            // 
            this.lbNome.AutoSize = true;
            this.lbNome.Location = new System.Drawing.Point(34, 104);
            this.lbNome.Name = "lbNome";
            this.lbNome.Size = new System.Drawing.Size(16, 13);
            this.lbNome.TabIndex = 6;
            this.lbNome.Text = "...";
            this.lbNome.Click += new System.EventHandler(this.lbNome_Click);
            // 
            // txtN2
            // 
            this.txtN2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtN2.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F);
            this.txtN2.Location = new System.Drawing.Point(92, 50);
            this.txtN2.Name = "txtN2";
            this.txtN2.Size = new System.Drawing.Size(30, 30);
            this.txtN2.TabIndex = 5;
            this.txtN2.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // txtN1
            // 
            this.txtN1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtN1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F);
            this.txtN1.Location = new System.Drawing.Point(56, 50);
            this.txtN1.Name = "txtN1";
            this.txtN1.Size = new System.Drawing.Size(30, 30);
            this.txtN1.TabIndex = 4;
            this.txtN1.TextChanged += new System.EventHandler(this.txtN1_TextChanged);
            // 
            // tbPartido
            // 
            this.tbPartido.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.tbPartido.Font = new System.Drawing.Font("Segoe UI", 8F);
            this.tbPartido.Location = new System.Drawing.Point(3, 138);
            this.tbPartido.Name = "tbPartido";
            this.tbPartido.Size = new System.Drawing.Size(47, 15);
            this.tbPartido.TabIndex = 3;
            this.tbPartido.Text = "Partido: ";
            this.tbPartido.TextChanged += new System.EventHandler(this.tbPartido_TextChanged);
            // 
            // tbNumero
            // 
            this.tbNumero.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.tbNumero.Font = new System.Drawing.Font("Segoe UI", 8F);
            this.tbNumero.Location = new System.Drawing.Point(3, 65);
            this.tbNumero.Name = "tbNumero";
            this.tbNumero.Size = new System.Drawing.Size(47, 15);
            this.tbNumero.TabIndex = 2;
            this.tbNumero.Text = "Numero:";
            this.tbNumero.TextChanged += new System.EventHandler(this.tbNumero_TextChanged);
            // 
            // tbNome
            // 
            this.tbNome.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.tbNome.Font = new System.Drawing.Font("Segoe UI", 8F);
            this.tbNome.Location = new System.Drawing.Point(3, 104);
            this.tbNome.Name = "tbNome";
            this.tbNome.Size = new System.Drawing.Size(42, 15);
            this.tbNome.TabIndex = 1;
            this.tbNome.Text = "Nome: ";
            // 
            // tbPresidente
            // 
            this.tbPresidente.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.tbPresidente.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.tbPresidente.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.tbPresidente.Location = new System.Drawing.Point(37, 17);
            this.tbPresidente.Name = "tbPresidente";
            this.tbPresidente.Size = new System.Drawing.Size(100, 18);
            this.tbPresidente.TabIndex = 0;
            this.tbPresidente.Text = "PRESIDENTE";
            this.tbPresidente.TextChanged += new System.EventHandler(this.tbPresidente_TextChanged);
            // 
            // lbVotos
            // 
            this.lbVotos.AutoSize = true;
            this.lbVotos.Location = new System.Drawing.Point(55, 61);
            this.lbVotos.Name = "lbVotos";
            this.lbVotos.Size = new System.Drawing.Size(16, 13);
            this.lbVotos.TabIndex = 14;
            this.lbVotos.Text = "...";
            // 
            // lbResultado
            // 
            this.lbResultado.AutoSize = true;
            this.lbResultado.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.lbResultado.Location = new System.Drawing.Point(48, 221);
            this.lbResultado.Name = "lbResultado";
            this.lbResultado.Size = new System.Drawing.Size(18, 19);
            this.lbResultado.TabIndex = 15;
            this.lbResultado.Text = "...";
            this.lbResultado.Click += new System.EventHandler(this.lbResultado_Click);
            // 
            // btnResultado
            // 
            this.btnResultado.Location = new System.Drawing.Point(34, 314);
            this.btnResultado.Name = "btnResultado";
            this.btnResultado.Size = new System.Drawing.Size(75, 23);
            this.btnResultado.TabIndex = 16;
            this.btnResultado.Text = "Resultado";
            this.btnResultado.UseVisualStyleBackColor = true;
            this.btnResultado.Click += new System.EventHandler(this.btnResultado_Click);
            // 
            // frmUrna
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoValidate = System.Windows.Forms.AutoValidate.EnablePreventFocusChange;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.CausesValidation = false;
            this.ClientSize = new System.Drawing.Size(1100, 654);
            this.ControlBox = false;
            this.Controls.Add(this.pnFim);
            this.Controls.Add(this.btnResultado);
            this.Controls.Add(this.lbResultado);
            this.Controls.Add(this.lbVotos);
            this.Controls.Add(this.pn1);
            this.Controls.Add(this.bt12);
            this.Controls.Add(this.bt11);
            this.Controls.Add(this.bt10);
            this.Controls.Add(this.bt0);
            this.Controls.Add(this.bt9);
            this.Controls.Add(this.bt8);
            this.Controls.Add(this.bt7);
            this.Controls.Add(this.bt6);
            this.Controls.Add(this.bt5);
            this.Controls.Add(this.bt4);
            this.Controls.Add(this.bt3);
            this.Controls.Add(this.bt2);
            this.Controls.Add(this.bt1);
            this.Cursor = System.Windows.Forms.Cursors.Default;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "frmUrna";
            this.Text = "URNA";
            this.Load += new System.EventHandler(this.URNA_Load);
            this.pn1.ResumeLayout(false);
            this.pn1.PerformLayout();
            this.pnFim.ResumeLayout(false);
            this.pnFim.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbfoto)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button bt1;
        private System.Windows.Forms.Button bt2;
        private System.Windows.Forms.Button bt3;
        private System.Windows.Forms.Button bt4;
        private System.Windows.Forms.Button bt5;
        private System.Windows.Forms.Button bt6;
        private System.Windows.Forms.Button bt7;
        private System.Windows.Forms.Button bt8;
        private System.Windows.Forms.Button bt9;
        private System.Windows.Forms.Button bt0;
        private System.Windows.Forms.Button bt10;
        private System.Windows.Forms.Button bt11;
        private System.Windows.Forms.Button bt12;
        private System.Windows.Forms.Panel pn1;
        private System.Windows.Forms.TextBox tbPresidente;
        private System.Windows.Forms.TextBox tbNumero;
        private System.Windows.Forms.TextBox tbNome;
        private System.Windows.Forms.TextBox tbPartido;
        private System.Windows.Forms.TextBox txtN1;
        private System.Windows.Forms.TextBox txtN2;
        private System.Windows.Forms.Label lbPartido;
        private System.Windows.Forms.Label lbNome;
        private System.Windows.Forms.PictureBox pbfoto;
        private System.Windows.Forms.Panel pnFim;
        private System.Windows.Forms.TextBox tbFim;
        private System.Windows.Forms.Timer relogio;
        private System.Windows.Forms.Label lbVotos;
        private System.Windows.Forms.Label lbResultado;
        private System.Windows.Forms.Button btnResultado;
    }
}