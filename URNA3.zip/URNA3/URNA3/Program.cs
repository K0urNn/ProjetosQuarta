﻿using System;
using System.Windows.Forms;
using URNA3;

namespace SeuProjeto
{
    static class Program
    {
        [STAThread]
        static void Main()
        {
            Console.WriteLine("Iniciando o programa...");

            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);

            try
            {
                // Cria uma instância do Form1 para ver se há algum problema no construtor
                frmUrna form = new frmUrna();
                Console.WriteLine("Formulário criado com sucesso.");

                // Inicia a aplicação com o formulário principal
                Application.Run(form);
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Erro: {ex.Message}");
                Console.ReadLine(); // Manter a janela do console aberta para leitura do erro
            }
        }
    }
}
