﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;



namespace calculadora {
    public partial class Form1 : Form {
        public decimal Resultado { get; set; }

        public decimal Valor { get; set; }
        private Operacao OpercaoSelecionada { get; set; }
        private enum Operacao {
            Adicao,
            Subtracao,
            Multiplicacao,
            Divisao
        }

        public Form1() {
            InitializeComponent();
        }

        private void btn_0_Click(object sender, EventArgs e) {
            txt_resultado.Text += "0";
        }

        private void btn_1_Click(object sender, EventArgs e) {
            txt_resultado.Text += "1";
        }

        private void btn_2_Click(object sender, EventArgs e) {
            txt_resultado.Text += "2";
        }

        private void btn_3_Click(object sender, EventArgs e) {
            txt_resultado.Text += "3";
        }

        private void btn_4_Click(object sender, EventArgs e) {
            txt_resultado.Text += "4";
        }

        private void btn_5_Click(object sender, EventArgs e) {
            txt_resultado.Text += "5";
        }

        private void btn_6_Click(object sender, EventArgs e) {
            txt_resultado.Text += "6";
        }

        private void btn_7_Click(object sender, EventArgs e) {
            txt_resultado.Text += "7";
        }

        private void btn_8_Click(object sender, EventArgs e) {
            txt_resultado.Text += "8";
        }

        private void btn_9_Click(object sender, EventArgs e) {
            txt_resultado.Text += "9";
        }

        private void btn_adicao_Click(object sender, EventArgs e) {
            OpercaoSelecionada = Operacao.Adicao;
            Valor = Convert.ToDecimal(txt_resultado.Text);
            txt_resultado.Text = "";
            lblOperacao.Text = "+";
        }

        private void btn_sub_Click(object sender, EventArgs e) {
            OpercaoSelecionada = Operacao.Subtracao;
            Valor = Convert.ToDecimal(txt_resultado.Text);
            txt_resultado.Text = "";
            lblOperacao.Text = "-";
        }

        private void btn_mult_Click(object sender, EventArgs e) {
            OpercaoSelecionada = Operacao.Multiplicacao;
            Valor = Convert.ToDecimal(txt_resultado.Text);
            txt_resultado.Text = "";
            lblOperacao.Text = "*";
        }

        private void btn_divisao_Click(object sender, EventArgs e) {
            OpercaoSelecionada = Operacao.Divisao;
            Valor = Convert.ToDecimal(txt_resultado.Text);
            txt_resultado.Text = "";
            lblOperacao.Text = "/";
        }

        private void btn_result_Click(object sender, EventArgs e) {
            switch (OpercaoSelecionada) {
                case Operacao.Adicao:
                    Resultado = Valor + Convert.ToDecimal(txt_resultado.Text);
                    break;
                case Operacao.Subtracao:
                    Resultado = Valor - Convert.ToDecimal(txt_resultado.Text);
                    break;
                case Operacao.Multiplicacao:
                    Resultado = Valor * Convert.ToDecimal(txt_resultado.Text);
                    break;
                case Operacao.Divisao:
                    Resultado = Valor / Convert.ToDecimal(txt_resultado.Text);
                    break;
            }
            txt_resultado.Text = Convert.ToString(Resultado);
            lblOperacao.Text = "=";

        }

        private void btn_virgula_Click(object sender, EventArgs e) {
            if (!txt_resultado.Text.Contains("."))
                txt_resultado.Text += ".";

        }

        private void btn_limpar_Click(object sender, EventArgs e) {
            txt_resultado.Text = "";
            lblOperacao.Text = "";
        }

        private void txt_resultado_TextChanged(object sender, EventArgs e) {

        }

        private void Form1_Load(object sender, EventArgs e) {

        }


    }
}